package com.example.androidmidterm;

import android.os.Bundle;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class ActivityMain extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main); // 這裡設置activity_main.xml的佈局


        // 在這裡你可以對textView和button進行操作，如設置文本、添加點擊事件等
    }
}
