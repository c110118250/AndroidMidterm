package com.example.androidmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAccount;
    private EditText editTextPassword;
    private Button buttonCancel;
    private Button buttonLogin;
    private Button buttonExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);

        editTextAccount = findViewById(R.id.editTextAccount);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonCancel = findViewById(R.id.buttonCancel);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonExit = findViewById(R.id.buttonExit);

        // Login 按鈕點擊事件
        buttonLogin.setOnClickListener(view -> {
            // 在這裡可以處理登入的相應操作

            // 創建意圖 (Intent) 來轉到 activity_main.xml 頁面
            Intent intent = new Intent(MainActivity.this, ActivityMain.class);

            // 將預設帳號和密碼作為 Extra 放入 Intent 中
            intent.putExtra("DEFAULT_ACCOUNT", "Account");
            intent.putExtra("DEFAULT_PASSWORD", "Password");

            // 啟動新的活動
            startActivity(intent);
        });

        // Exit 按鈕點擊事件
        buttonExit.setOnClickListener(view -> finish()); // 結束應用程式

        // Cancel 按鈕點擊事件
        buttonCancel.setOnClickListener(view -> {
            // 清空 EditText 內容
            editTextAccount.setText("");
            editTextPassword.setText("");
        });
    }

}