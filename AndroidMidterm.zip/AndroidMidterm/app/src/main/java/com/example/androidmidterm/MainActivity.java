package com.example.androidmidterm;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class MainActivity extends AppCompatActivity {

    private EditText editTextAccount;
    private EditText editTextPassword;
    private Button buttonCancel;
    private Button buttonLogin;
    private Button buttonExit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_main);

        editTextAccount = findViewById(R.id.editTextAccount);
        editTextPassword = findViewById(R.id.editTextPassword);
        buttonCancel = findViewById(R.id.buttonCancel);
        buttonLogin = findViewById(R.id.buttonLogin);
        buttonExit = findViewById(R.id.buttonExit);

        // Login 按鈕點擊事件
        buttonLogin.setOnClickListener(view -> {
            // 獲取輸入的帳號和密碼
            String enteredAccount = editTextAccount.getText().toString();
            String enteredPassword = editTextPassword.getText().toString();

            // 檢查帳號和密碼是否正確
            boolean isAccountValid = enteredAccount.equals("Account");
            boolean isPasswordValid = enteredPassword.equals("Password");

            if (isAccountValid && isPasswordValid) {
                // 創建意圖 (Intent) 來轉到 ActivityMain 頁面
                Intent intent = new Intent(MainActivity.this, ActivityMain.class);

                // 將預設帳號和密碼作為 Extra 放入 Intent 中
                intent.putExtra("DEFAULT_ACCOUNT", "Account");
                intent.putExtra("DEFAULT_PASSWORD", "Password");

                // 啟動新的活動
                startActivity(intent);
            } else {
                // 顯示錯誤訊息
                Toast.makeText(MainActivity.this, "帳號密碼錯誤", Toast.LENGTH_SHORT).show();

                // 清空 EditText 內容
                editTextAccount.setText("");
                editTextPassword.setText("");
            }
        });

        // Exit 按鈕點擊事件
        buttonExit.setOnClickListener(view -> finish()); // 結束應用程式

        // Cancel 按鈕點擊事件
        buttonCancel.setOnClickListener(view -> {
            // 清空 EditText 內容
            editTextAccount.setText("");
            editTextPassword.setText("");
        });
    }


    @Override
    protected void onStart() {
        // Call the superclass method first.
        super.onStart();

        Toast.makeText(this, "onStart()...", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onResume() {
        // Call the superclass method first.
        super.onResume();

        Toast.makeText(this, "onResume()...", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onPause() {
        // Call the superclass method first.
        super.onPause();

        Toast.makeText(this, "onPause()...", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onRestart() {
        // Call the superclass method first.
        super.onRestart();

        Toast.makeText(this, "onRestart...", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onStop() {
        // Call the superclass method first.
        super.onStop();

        Toast.makeText(this, "onStop()...", Toast.LENGTH_LONG).show();
    }

    @Override
    protected void onDestroy() {
        // Call the superclass method first.
        super.onDestroy();

        Toast.makeText(this, "onDestroy()...", Toast.LENGTH_LONG).show();
    }

}